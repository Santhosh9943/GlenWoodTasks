Payment Portal UI:
=================

cat /etc/httpd/conf/httpd.conf

Alias /billing/desktop /var/version/PaymentPortal/paymentportal_ui/paymentportal_ui_desktop_stage/target/paymentportal_ui-5.0-SNAPSHOT/
<Directory "/var/version/PaymentPortal/paymentportal_ui/paymentportal_ui_desktop_stage/target/paymentportal_ui-5.0-SNAPSHOT/">
    AllowOverride None
    Options None
    Require all granted
</Directory>



cd /var/version/PaymentPortal/paymentportal_ui/paymentportal_ui_desktop_stage
ls -lrth

Console:
========

[root@portal tmp]# cd /var/version/PaymentPortal/paymentportal_ui/paymentportal_ui_desktop
[root@portal paymentportal_ui_desktop]# 
[root@portal paymentportal_ui_desktop]# 
[root@portal paymentportal_ui_desktop]# 
[root@portal paymentportal_ui_desktop]# ls -lrth
total 4.0K
drwxrwxrwx 11 root root 4.0K Jan 25  2022 target
[root@portal paymentportal_ui_desktop]# 

rsync -avrzh --progress root@ci:/var/lib/jenkins/jobs/paymentportal_ui_job/workspace/target /var/version/PaymentPortal/paymentportal_ui/paymentportal_ui_desktop_stage/

[root@portal tmp]# service httpd status
Redirecting to /bin/systemctl status  httpd.service
● httpd.service - The Apache HTTP Server
   Loaded: loaded (/usr/lib/systemd/system/httpd.service; enabled; vendor preset: disabled)
   Active: active (running) since Mon 2023-03-06 05:13:28 EST; 21h ago
     Docs: man:httpd(8)
           man:apachectl(8)
 Main PID: 1032 (httpd)
   CGroup: /system.slice/httpd.service
           ├─ 1032 /usr/sbin/httpd -DFOREGROUND
           ├─13823 /usr/sbin/httpd -DFOREGROUND
           ├─14509 /usr/sbin/httpd -DFOREGROUND
           ├─16377 /usr/sbin/httpd -DFOREGROUND
           ├─28903 /usr/sbin/httpd -DFOREGROUND
           ├─29057 /usr/sbin/httpd -DFOREGROUND
           ├─29208 /usr/sbin/httpd -DFOREGROUND
           ├─61228 /usr/sbin/httpd -DFOREGROUND
           ├─77303 /usr/sbin/httpd -DFOREGROUND
           ├─77346 /usr/sbin/httpd -DFOREGROUND
           └─77354 /usr/sbin/httpd -DFOREGROUND

Mar 06 05:13:28 kiosk.glaceemr.com systemd[1]: Started The Apache HTTP Server.
Mar 06 05:13:28 kiosk.glaceemr.com systemd[1]: Starting The Apache HTTP Server...



[root@portal tmp]# service httpd restart
Redirecting to /bin/systemctl restart  httpd.service


[root@portal tmp]# service httpd status
Redirecting to /bin/systemctl status  httpd.service
● httpd.service - The Apache HTTP Server
   Loaded: loaded (/usr/lib/systemd/system/httpd.service; enabled; vendor preset: disabled)
   Active: active (running) since Tue 2023-03-07 02:22:57 EST; 1s ago
     Docs: man:httpd(8)
           man:apachectl(8)
  Process: 84136 ExecStop=/bin/kill -WINCH ${MAINPID} (code=exited, status=0/SUCCESS)
 Main PID: 84140 (httpd)
   CGroup: /system.slice/httpd.service
           ├─84140 /usr/sbin/httpd -DFOREGROUND
           ├─84141 /usr/sbin/httpd -DFOREGROUND
           ├─84142 /usr/sbin/httpd -DFOREGROUND
           ├─84143 /usr/sbin/httpd -DFOREGROUND
           ├─84144 /usr/sbin/httpd -DFOREGROUND
           └─84145 /usr/sbin/httpd -DFOREGROUND

Mar 07 02:22:57 kiosk.glaceemr.com systemd[1]: Started The Apache HTTP Server.
Mar 07 02:22:57 kiosk.glaceemr.com systemd[1]: Starting The Apache HTTP Server...
