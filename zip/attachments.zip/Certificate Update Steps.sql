To List the certs in jks:-

keytool -list -v -keystore keystore.jks -alias glenwoodsystems2021

To Import -

keytool -importcert -alias EpicInter -file EpicInter.cer -keystore /mnt/keystores/truststore.jks

To Export -

keytool -export -alias glenwoodsystems.com -keystore glenwoodsystems.com.jks -rfc -file glenwood2021_New.cer

To Import one jks to another jks -

keytool -importkeystore -srckeystore glenwoodsystems.com.jks -destkeystore keystore.jks

To Change alias name in jks file -

keytool -changealias -alias glenwoodsystems.com -destalias glenwoodsystems2021 -keystore keystore.jks 
