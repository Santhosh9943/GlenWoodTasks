Portal1 server glaceportal_data Update - Console

cd /var/version/glaceportal_data_hxxx  -- Path
ls -lrht
svn info  -- To confirm the correct path.
======================================================================
Path: .
Working Copy Root Path: /var/version/glaceportal_data_hxxx
URL: http://svn1.glaceemr.com:18080/svn/glacegwt/glaceportal_data_hxxx
Repository Root: http://svn1.glaceemr.com:18080/svn/glacegwt
Repository UUID: ee589d99-0113-467c-92c2-acc0d97f98a1
Revision: 12119
Node Kind: directory
Schedule: normal
Last Changed Author: bhagyalakshmi
Last Changed Rev: 12119
Last Changed Date: 2020-01-16 06:43:40 -0500 (Thu, 16 Jan 2020)
========================================================================
 ll src/main/java/com/glenwood/glaceportal/server/application/entities/PortalMessage.java  -- To check the file.
cp -r src/main/java/com/glenwood/glaceportal/server/application/entities/PortalMessage.java /var/backup/PortalMessage_Jan07.java  -- Backup of current file under /var/backup.
ll /var/backup/PortalMessage_Jan07.java  -- confirm Backup file.
ls -lrht
mv target target_Jan07 -- Take current working target.
ls -rlth
svn up src/main/java/com/glenwood/glaceportal/server/application/entities/PortalMessage.java  -- update given file.
========================================================================
Updating 'src/main/java/com/glenwood/glaceportal/server/application/entities/PortalMessage.java':
U src/main/java/com/glenwood/glaceportal/server/application/entities/PortalMessage.java
Updated to revision 12619.
========================================================================
ll src/main/java/com/glenwood/glaceportal/server/application/entities/PortalMessage.java  -- After completed updated of the file check updated date.
========================================================================
-rwxr-xr-x 1 root root 3812 Jan  7 01:07 src/main/java/com/glenwood/glaceportal/server/application/entities/PortalMessage.java
========================================================================
ls -lrht
cat Target.sh
===================
mvn clean package
===================
sh Target.sh  -- Run the script for genrate the new target.
ls -lrth
chmod -Rf 777 target  -- Give permission for the new target file.
ls -lrth
cd /usr/share/tomcat/apache-tomcat-9.0.14/webapps/
mv glaceportal_data.war /var/backup/glaceportal_data_Jan07.war  -- Take Backup of the current war file.
ll /var/backup/glaceportal_data_Jan07.war
cd /var/version/glaceportal_data_hxxx
ls -rlth
cd target
ls -lrth
cp -r target/glaceportal_data.war /usr/share/tomcat/apache-tomcat-9.0.14/webapps/  -- To take newly created war file and put under the webapps.
cd /usr/share/tomcat/apache-tomcat-9.0.14/webapps/
ls -lrth
chmod -Rf 777 glaceportal_data.war  -- permission
chmod -Rf 777 glaceportal_data
ls -lrth
