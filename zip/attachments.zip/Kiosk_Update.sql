Connect Kiosk
=============

cd /usr/share/tomcat/apache-tomcat-9.0.19/conf/Catalina/localhost

cat kiosk_data.xml -- For Verfiying Correct Codebase path
cat kiosklogin.xml -- For Verfiying Correct Codebase path
cat kioskpwa.xml -- For Verfiying Correct Codebase path

===========================================================================================================================================================
Console:
========
[root@kiosk localhost]# cat kiosk_data.xml
<Context path="/kiosk_data" displayName="development" docBase="/var/version/Glaceemr_Kiosk/kiosk_data_src/target/kiosk_data" reloadable="true" >
   <!-- Default set of monitored resources -->
    <WatchedResource>WEB-INF/web.xml</WatchedResource>    

    <!-- Uncomment this to disable session persistence across Tomcat restarts -->
    <!--
    <Manager pathname="" />
    -->
</Context>
===========================================================================================================================================================
[root@kiosk localhost]# 
[root@kiosk localhost]# cat kiosklogin.xml
<Context path="/kiosklogin" displayName="development" docBase="/var/version/Glaceemr_Kiosk/glacekiosk_login/target/glacekiosk_login" reloadable="true" >
   <!-- Default set of monitored resources -->
    <WatchedResource>WEB-INF/web.xml</WatchedResource>    

    <!-- Uncomment this to disable session persistence across Tomcat restarts -->
    <!--
    <Manager pathname="" />
    -->
</Context>
=========================================================================================================================================================== 
[root@kiosk localhost]# cat kioskpwa.xml
<Context path="/kioskpwa" displayName="kioskpwa" docBase="/var/version/KioskPWA" reloadable="true" >
   <!-- Default set of monitored resources -->
    <WatchedResource>WEB-INF/web.xml</WatchedResource>    

    <!-- Uncomment this to disable session persistence across Tomcat restarts -->
    <!--
    <Manager pathname="" />
    -->
</Context>
===========================================================================================================================================================

kiosk_data:
==========
cd /var/version/Glaceemr_Kiosk/kiosk_data_src
ls -lrth

Console:
========
[root@kiosk kiosk_data_src]# ls -lrth
total 16K
drwxrwxrwx 3 root    root        18 Nov 15  2021 src
drwxrwxrwx 6 root    root       109 Nov 15  2021 target_Feb18
drwxrwxrwx 6 towsif  adminusers 109 Feb 15  2022 target_Jun08
-rwxr-xr-x 1 root    root       13K Feb 18  2022 pom.xml
drwxrwxrwx 6 root    root       109 Mar  3 04:47 target_Mar06
drwxrwxrwx 6 vignesh adminusers 109 Mar  6 05:17 target

Hints::Please take the Backup of working target with todays date and please maintence only two backups and one target folder.

mv target target_Mar06_1

[root@kiosk kiosk_data_src]# ls -lrth
total 16K
drwxrwxrwx 3 root    root        18 Nov 15  2021 src
drwxrwxrwx 6 root    root       109 Nov 15  2021 target_Feb18
drwxrwxrwx 6 towsif  adminusers 109 Feb 15  2022 target_Jun08
-rwxr-xr-x 1 root    root       13K Feb 18  2022 pom.xml
drwxrwxrwx 6 root    root       109 Mar  3 04:47 target_Mar06
drwxrwxrwx 6 vignesh adminusers 109 Mar  6 05:17 target_Mar06_1

Connect CI Server:
=================

cd /var/lib/jenkins/jobs/glacekiosk_job/workspace
ls -lrth


Console:
========
root@ci:/var/lib/jenkins/jobs/glacekiosk_job/workspace# ls -lrth
total 24K
drwxr-xr-x 3 jenkins nogroup 4.0K Mar  6 05:16 src
-rwxr-xr-x 1 jenkins nogroup  13K Mar  6 05:16 pom.xml
drwxr-xr-x 6 jenkins nogroup 4.0K Mar  6 05:17 target


Rsync to Kiosk Server:
======================

rsync -avrzh --progress target vignesh@kiosk.glaceemr.com:/var/version/Glaceemr_Kiosk/kiosk_data_src/


Connect Kiosk Server:
=====================

ps -ef | grep -i java
tomcat     1224      1 50 05:21 ?        09:18:29 /usr/java/jdk-10.0.2/bin/java -Djava.util.logging.config.file=/usr/share/tomcat/apache-tomcat-9.0.19/conf/logging.properties -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -Djdk.tls.ephemeralDHKeySize=2048 -Djava.protocol.handler.pkgs=org.apache.catalina.webresources -Dorg.apache.catalina.security.SecurityListener.UMASK=0027 -Djava.library.path=/usr/local/apr/lib -verbose:gc -Djava.awt.headless=true -Djavax.xml.parsers.SAXParserFactory=org.apache.xerces.jaxp.SAXParserFactoryImpl -Xlog:gc*:file=/usr/share/tomcat/apache-tomcat-9.0.19/logs/gc.log -Dignore.endorsed.dirs= -classpath /usr/share/tomcat/apache-tomcat-9.0.19/bin/bootstrap.jar:/usr/share/tomcat/apache-tomcat-9.0.19/bin/tomcat-juli.jar -Dcatalina.base=/usr/share/tomcat/apache-tomcat-9.0.19 -Dcatalina.home=/usr/share/tomcat/apache-tomcat-9.0.19 -Djava.io.tmpdir=/usr/share/tomcat/apache-tomcat-9.0.19/temp org.apache.catalina.startup.Bootstrap start
root      25754  25740  0 23:57 pts/1    00:00:00 grep --color=auto -i java

kill -9 1224

service tomcat9 restart

===========================================================================================================================================================

kiosk_login:
==========
cd /var/version/Glaceemr_Kiosk/glacekiosk_login
ls -lrth

Console:
========
[root@kiosk glacekiosk_login]# ls -lrth
total 16K
drwxrwxrwx 3 root    root        18 Nov 15  2021 src
drwxrwxrwx 6 root    root       109 Nov 15  2021 target_Feb18
drwxrwxrwx 6 towsif  adminusers 109 Feb 15  2022 target_Jun08
-rwxr-xr-x 1 root    root       13K Feb 18  2022 pom.xml
drwxrwxrwx 6 root    root       109 Mar  3 04:47 target_Mar06
drwxrwxrwx 6 vignesh adminusers 109 Mar  6 05:17 target

Hints::Please take the Backup of working target with todays date and please maintence only two backups and one target folder.

mv target target_Mar06_1

[root@kiosk glacekiosk_login]# ls -lrth
total 16K
drwxrwxrwx 3 root    root        18 Nov 15  2021 src
drwxrwxrwx 6 root    root       109 Nov 15  2021 target_Feb18
drwxrwxrwx 6 towsif  adminusers 109 Feb 15  2022 target_Jun08
-rwxr-xr-x 1 root    root       13K Feb 18  2022 pom.xml
drwxrwxrwx 6 root    root       109 Mar  3 04:47 target_Mar06
drwxrwxrwx 6 vignesh adminusers 109 Mar  6 05:17 target_Mar06_1

svn up (File name)
mvn clean packge -- For Creating the New Target.(Converting java file to class file.)

cd /usr/share/tomcat/apache-tomcat-9.0.19/webapps/

mv glacekiosk_login.war /var/backup/glacekiosk_login_Mar07.war

cp -r /var/version/Glaceemr_Kiosk/glacekiosk_login/target/glacekiosk_login.war /usr/share/tomcat/apache-tomcat-9.0.19/webapps/

kill -9 1224

service tomcat9 restart

===========================================================================================================================================================

KioskPWA:
==========
cd /var/version/KioskPWA
ls -lrth

mv /var/version/KioskPWA /var/backup/KioskPWA_Mar07

Notes::Developer will give the project as a zip we need Replace the Project.


===========================================================================================================================================================

Kiosk_UI:
=========

cat /etc/httpd/conf/httpd.conf

Alias /kiosk /var/version/Glaceemr_Kiosk/glaceemr_kiosk_ui/target/glacekiosk_ui-5.0-SNAPSHOT/ 
<Directory "/var/version/Glaceemr_Kiosk/glaceemr_kiosk_ui/target/glacekiosk_ui-5.0-SNAPSHOT/">
    AllowOverride None
    Options none
    Require all granted
</Directory>


cd /var/version/Glaceemr_Kiosk/glaceemr_kiosk_ui/
ls -lrth

Hints::Please take the Backup of working target with todays date and please maintence only two backups and one target folder.

[root@kiosk glaceemr_kiosk_ui]# ls -lrth
total 12K
-rwxrwxrwx  1 root root  121 Nov 15  2021 README.md
drwxrwxrwx  3 root root   18 Nov 15  2021 gwt-qrscanner
-rwxrwxrwx  1 root root 7.6K Nov 15  2021 pom.xml
drwxrwxrwx  4 root root   30 Nov 15  2021 src
drwxrwxrwx 10 root root  227 Feb 22 07:39 target_mar3
drwxrwxrwx 10 root root  227 Mar  2 20:24 target

mv target target_Mar06_1

Console:
========
[root@kiosk glaceemr_kiosk_ui]# ls -lrth
total 12K
-rwxrwxrwx  1 root root  121 Nov 15  2021 README.md
drwxrwxrwx  3 root root   18 Nov 15  2021 gwt-qrscanner
-rwxrwxrwx  1 root root 7.6K Nov 15  2021 pom.xml
drwxrwxrwx  4 root root   30 Nov 15  2021 src
drwxrwxrwx 10 root root  227 Feb 22 07:39 target_mar3
drwxrwxrwx 10 root root  227 Mar  2 20:24 target_Mar06_1


Connect CI Server:
=================

cd /var/lib/jenkins/jobs/glacekiosk_job/workspace
ls -lrth


Console:
========
root@ci:/var/lib/jenkins/jobs/glacekiosk_ui_job//workspace# ls -lrth
total 24K
drwxr-xr-x 3 jenkins nogroup 4.0K Mar  6 05:16 src
-rwxr-xr-x 1 jenkins nogroup  13K Mar  6 05:16 pom.xml
drwxr-xr-x 6 jenkins nogroup 4.0K Mar  6 05:17 target


Rsync to Kiosk Server:
======================

rsync -avrzh --progress target vignesh@kiosk.glaceemr.com:/var/version/Glaceemr_Kiosk/glaceemr_kiosk_ui/

service httpd status

service httpd restart

Console:
========

[root@kiosk glaceemr_kiosk_ui]# service httpd status
Redirecting to /bin/systemctl status  httpd.service
● httpd.service - The Apache HTTP Server
   Loaded: loaded (/usr/lib/systemd/system/httpd.service; enabled; vendor preset: disabled)
   Active: active (running) since Mon 2023-03-06 05:13:28 EST; 21h ago
     Docs: man:httpd(8)
           man:apachectl(8)
 Main PID: 1032 (httpd)
   CGroup: /system.slice/httpd.service
           ├─ 1032 /usr/sbin/httpd -DFOREGROUND
           ├─13823 /usr/sbin/httpd -DFOREGROUND
           ├─14509 /usr/sbin/httpd -DFOREGROUND
           ├─16377 /usr/sbin/httpd -DFOREGROUND
           ├─28903 /usr/sbin/httpd -DFOREGROUND
           ├─29057 /usr/sbin/httpd -DFOREGROUND
           ├─29208 /usr/sbin/httpd -DFOREGROUND
           ├─61228 /usr/sbin/httpd -DFOREGROUND
           ├─77303 /usr/sbin/httpd -DFOREGROUND
           ├─77346 /usr/sbin/httpd -DFOREGROUND
           └─77354 /usr/sbin/httpd -DFOREGROUND

Mar 06 05:13:28 kiosk.glaceemr.com systemd[1]: Started The Apache HTTP Server.
Mar 06 05:13:28 kiosk.glaceemr.com systemd[1]: Starting The Apache HTTP Server...



[root@kiosk glaceemr_kiosk_ui]# service httpd restart
Redirecting to /bin/systemctl restart  httpd.service


[root@kiosk glaceemr_kiosk_ui]# service httpd status
Redirecting to /bin/systemctl status  httpd.service
● httpd.service - The Apache HTTP Server
   Loaded: loaded (/usr/lib/systemd/system/httpd.service; enabled; vendor preset: disabled)
   Active: active (running) since Tue 2023-03-07 02:22:57 EST; 1s ago
     Docs: man:httpd(8)
           man:apachectl(8)
  Process: 84136 ExecStop=/bin/kill -WINCH ${MAINPID} (code=exited, status=0/SUCCESS)
 Main PID: 84140 (httpd)
   CGroup: /system.slice/httpd.service
           ├─84140 /usr/sbin/httpd -DFOREGROUND
           ├─84141 /usr/sbin/httpd -DFOREGROUND
           ├─84142 /usr/sbin/httpd -DFOREGROUND
           ├─84143 /usr/sbin/httpd -DFOREGROUND
           ├─84144 /usr/sbin/httpd -DFOREGROUND
           └─84145 /usr/sbin/httpd -DFOREGROUND

Mar 07 02:22:57 kiosk.glaceemr.com systemd[1]: Started The Apache HTTP Server.
Mar 07 02:22:57 kiosk.glaceemr.com systemd[1]: Starting The Apache HTTP Server...





===========================================================================================================================================================





