======================
Connect 16.3 Server:
======================
Connect Server 16.3
cd /tmp
su glace
Take drugdb Dump from Given {DB:-DBNAME}

Step1:
==============
DUMP COMMAND:-
==============
pg_dump -p 5432 -v -Fc  drugDB_medispan_update | 7za a -p'th3s@cr3ts3rv!ce' -mhe=on -r -m0=lzma -mx=9 -mfb=64 -md=32m -si drugDB_medispan_update_Aug03.7z

Step2:
======
Drop Old Backup Command given Below.
dropdb 'drugDB_medispan_(Old_Date_BKP)'
Example:
========
dropdb 'drugDB_medispan_july07'

Step3:
=====
Rename the Present DB to Old DB Command given below.
=====================================================
psql Postgres
ALTER DATABASE "drugDB_medispan" RENAME TO "drugDB_medispan_Aug03";

Step4:
======
Create New DB with same name which is in production Command given below
========================================================================
su glace
createdb drugDB_medispan -E SQL_ASCII -T template0;

Step5:
======
Rsync taken backup file to belwo mention servers:

New:-
=====
rsync -avzr --progress drugDB_medispan_update_Aug03.7z towsif@172.16.16.5:/tmp/
rsync -avzr --progress drugDB_medispan_update_Aug03.7z  glenwood@waterburysrv.glaceemr.net:/tmp

Connect Waterbury Server:
=========================
rsync -avzr drugDB_medispan_update_Aug03.7z  root@10.1.10.42:/tmp
rsync -rvz -e 'ssh -p 23'   drugDB_medispan_update_Aug03.7z  towsif@hammad.glaceemr.net:/tmp

=========================================================================================================================================


ALTER DATABASE "drugDB_medispan" RENAME TO "drugDB_medispan_Aug03";

createdb drugDB_medispan -E SQL_ASCII -T template0;

7za x -p'th3s@cr3ts3rv!ce' -so drugDB_medispan_update_Aug03.7z | pg_restore -p 5432  -v -d drugDB_medispan

===================================================================================================================
After Complete 16.3 and 16.5 Server Connect Datagateway serves one by one and below mention Redis FLUSHALL Command
===================================================================================================================
Note1:If Datagateway1 is up then do Datagateway2 like that need to do all Datagateway servers.

Command:
=========
redis-cli FLUSHALL 

Note2:Then Restart Redis take from crontab:-
1.sh  /var/shellscript/RedisStart.sh
2.tail -f /usr/share/tomcat/apache-tomcat-9.0.12/logs/catalina.out
3.elinks "http://127.0.0.1/DataGatewayMediSpan"
=========================================================================================================

=========================================================================================================
After Complete Waterbury 10.1.10.42 and Hammad Mirror Server and give below mention Redis FLUSHALL Command
=========================================================================================================
Note1:Connect Hammad Mirror Server 

Command:
=========
redis-cli FLUSHALL

Note2:Then Restart Redis take from crontab:-
1.sh  /var/version/script/RedisStart.sh
2.tail -f /usr/share/tomcat/apache-tomcat-9.0.12/logs/catalina.out
3.elinks "http://127.0.0.1/DataGatewayMediSpan"
=========================================================================================================


