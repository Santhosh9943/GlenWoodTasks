Connect 172.17.24.150
=====================

cd /usr/share/tomcat/apache-tomcat-9.0.19/conf/Catalina/localhost 

cat glaceemr_backend.xml -- For Verfiying Correct Codebase path

Console:
========
[root@demosprings localhost]# cat glaceemr_backend.xml
<!-- The contents of this file will be loaded for each web application -->
<Context path="/glaceemr_backend" displayName="GlaceSpring" docBase="/var/version/NRVBetaSpring/target/glaceemr_backend" reloadable="true" >
</Context>


cd /var/version/NRVBetaSpring/
ls -lrth

Console:
========
[root@demosprings localhost]# cd /var/version/NRVBetaSpring/
[root@demosprings NRVBetaSpring]# 
[root@demosprings NRVBetaSpring]# 
[root@demosprings NRVBetaSpring]# 
[root@demosprings NRVBetaSpring]# 
[root@demosprings NRVBetaSpring]# 
[root@demosprings NRVBetaSpring]# ls -lrth
total 76K
-rwxrwxrwx 1 prasanna adminusers   63 Aug 25  2021 README.md
-rwxrwxrwx 1 prasanna adminusers  25K Aug 25  2021 pom.xml
drwxrwxrwx 4 root     root         30 Aug 25  2021 src
drwxrwxrwx 3 root     root         34 Aug 25  2021 bin
-rwxr-xr-x 1 root     root       5.9K Jan 29  2022 DataBaseAccessFilter_demo.class
drwxrwxrwx 9 root     root        195 May  9  2022 target_Nov08
-rwxr-xr-x 1 root     root        21K Nov 15 02:28 applicationContext.xml
-rwxrwxrwx 1 prasanna adminusers 8.6K Nov 16 02:11 application.properties
drwxrwxrwx 9 root     root        195 Mar  6 03:07 target_Mar06_1
drwxrwxrwx 9 root     root        195 Mar  6 10:39 target


Hints::Please take the Backup of working target with todays date and please maintence only two backups and one target folder.

mv target target_Mar06

Console:
========
[root@demosprings NRVBetaSpring]# ls -lrth
total 76K
-rwxrwxrwx 1 prasanna adminusers   63 Aug 25  2021 README.md
-rwxrwxrwx 1 prasanna adminusers  25K Aug 25  2021 pom.xml
drwxrwxrwx 4 root     root         30 Aug 25  2021 src
drwxrwxrwx 3 root     root         34 Aug 25  2021 bin
-rwxr-xr-x 1 root     root       5.9K Jan 29  2022 DataBaseAccessFilter_demo.class
drwxrwxrwx 9 root     root        195 May  9  2022 target_Nov08
-rwxr-xr-x 1 root     root        21K Nov 15 02:28 applicationContext.xml
-rwxrwxrwx 1 prasanna adminusers 8.6K Nov 16 02:11 application.properties
drwxrwxrwx 9 root     root        195 Mar  6 03:07 target_Mar06_1
drwxrwxrwx 9 root     root        195 Mar  6 10:39 target_Mar06

Now connect to version server IP:172.17.31.30

ssh 172.17.31.30

Go to Central Springs updating path:

cd /mnt/MainStorage/version/CentralSprings/NRVBetaSpring
ls -lrth

Console:
========
[root@version1 NRVBetaSpring]# ls -lrth
total 908K
-rwxrwxrwx. 1 root   root     63 Mar 18  2021 README.md
drwxrwxrwx. 3 root   root     34 Mar 18  2021 bin
drwxrwxrwx. 4 root   root     30 Mar 18  2021 src
-rwxr-xr-x. 1 root   root   9.7K Oct  6  2021 GlaceMonitoringAdapter.jsp
-rwxr-xr-x. 1 root   root   6.0K Oct  6  2021 DataBaseAccessFilter_old.class
-rwxr-xr-x. 1 root   root   117K Jan 25  2022 application_NRV_Jan25.properties
-rwxr-xr-x. 1 root   root   218K Jan 25  2022 applicationContext_NRV_Jan25.xml
-rw-r--r--. 1 root   root    36K Sep  7 01:31 pom.xml
-rwxr-xr-x. 1 root   root   6.7K Jan  4 00:18 DataBaseAccessFilter.class
-rwxrwxrwx. 1 tomcat tomcat 241K Feb 21 02:52 applicationContext.xml
-rwxrwxrwx. 1 root   root   128K Feb 28 11:27 application_BKP.properties
-rwxrwxrwx. 1 tomcat tomcat 128K Mar  1 00:52 application.properties
drwxrwxrwx. 9 root   root    195 Mar  6 09:24 target_Mar06_2
drwxrwxrwx. 9 root   root    195 Mar  6 10:39 target

Hints::Please take the Backup of working target with todays date and please maintence only two backups and one target folder.

mv target target_Mar06

[root@version1 NRVBetaSpring]# ls -lrth
total 908K
-rwxrwxrwx. 1 root   root     63 Mar 18  2021 README.md
drwxrwxrwx. 3 root   root     34 Mar 18  2021 bin
drwxrwxrwx. 4 root   root     30 Mar 18  2021 src
-rwxr-xr-x. 1 root   root   9.7K Oct  6  2021 GlaceMonitoringAdapter.jsp
-rwxr-xr-x. 1 root   root   6.0K Oct  6  2021 DataBaseAccessFilter_old.class
-rwxr-xr-x. 1 root   root   117K Jan 25  2022 application_NRV_Jan25.properties
-rwxr-xr-x. 1 root   root   218K Jan 25  2022 applicationContext_NRV_Jan25.xml
-rw-r--r--. 1 root   root    36K Sep  7 01:31 pom.xml
-rwxr-xr-x. 1 root   root   6.7K Jan  4 00:18 DataBaseAccessFilter.class
-rwxrwxrwx. 1 tomcat tomcat 241K Feb 21 02:52 applicationContext.xml
-rwxrwxrwx. 1 root   root   128K Feb 28 11:27 application_BKP.properties
-rwxrwxrwx. 1 tomcat tomcat 128K Mar  1 00:52 application.properties
drwxrwxrwx. 9 root   root    195 Mar  6 09:24 target_Mar06_2
drwxrwxrwx. 9 root   root    195 Mar  6 10:39 target_Mar06


git pull --For Receiving Commented Files.

mvn clean package -- For Creating the New Target.(Converting java file to class file.)

ls -lrth

[root@version1 NRVBetaSpring]# ls -lrth
total 908K
-rwxrwxrwx. 1 root   root     63 Mar 18  2021 README.md
drwxrwxrwx. 3 root   root     34 Mar 18  2021 bin
drwxrwxrwx. 4 root   root     30 Mar 18  2021 src
-rwxr-xr-x. 1 root   root   9.7K Oct  6  2021 GlaceMonitoringAdapter.jsp
-rwxr-xr-x. 1 root   root   6.0K Oct  6  2021 DataBaseAccessFilter_old.class
-rwxr-xr-x. 1 root   root   117K Jan 25  2022 application_NRV_Jan25.properties
-rwxr-xr-x. 1 root   root   218K Jan 25  2022 applicationContext_NRV_Jan25.xml
-rw-r--r--. 1 root   root    36K Sep  7 01:31 pom.xml
-rwxr-xr-x. 1 root   root   6.7K Jan  4 00:18 DataBaseAccessFilter.class
-rwxrwxrwx. 1 tomcat tomcat 241K Feb 21 02:52 applicationContext.xml
-rwxrwxrwx. 1 root   root   128K Feb 28 11:27 application_BKP.properties
-rwxrwxrwx. 1 tomcat tomcat 128K Mar  1 00:52 application.properties
drwxrwxrwx. 9 root   root    195 Mar  6 09:24 target_Mar06_2
drwxrwxrwx. 9 root   root    195 Mar  6 10:39 target_Mar06
drwxrwxrwx. 9 root   root    195 Mar  6 10:39 target

Rsync to Demo Spring Server:

rsync -avrzh --progress target root@172.17.24.150:/var/version/NRVBetaSpring/



Connect 172.17.24.150:

ssh 172.17.24.150
cd /var/version/NRVBetaSpring/
ls -lrth


-rwxrwxrwx. 1 root   root     63 Mar 18  2021 README.md
drwxrwxrwx. 3 root   root     34 Mar 18  2021 bin
drwxrwxrwx. 4 root   root     30 Mar 18  2021 src
-rwxr-xr-x. 1 root   root   9.7K Oct  6  2021 GlaceMonitoringAdapter.jsp
-rwxr-xr-x. 1 root   root   6.0K Oct  6  2021 DataBaseAccessFilter_old.class
-rwxr-xr-x. 1 root   root   117K Jan 25  2022 application_NRV_Jan25.properties
-rwxr-xr-x. 1 root   root   218K Jan 25  2022 applicationContext_NRV_Jan25.xml
-rw-r--r--. 1 root   root    36K Sep  7 01:31 pom.xml
-rwxr-xr-x. 1 root   root   6.7K Jan  4 00:18 DataBaseAccessFilter.class
-rwxrwxrwx. 1 tomcat tomcat 241K Feb 21 02:52 applicationContext.xml
-rwxrwxrwx. 1 root   root   128K Feb 28 11:27 application_BKP.properties
-rwxrwxrwx. 1 tomcat tomcat 128K Mar  1 00:52 application.properties
drwxrwxrwx. 9 root   root    195 Mar  6 09:24 target_Mar06_2
drwxrwxrwx. 9 root   root    195 Mar  6 10:39 target_Mar06
drwxrwxrwx. 9 root   root    195 Mar  6 10:39 target

Copy applicationContext.xml to New Target:
==========================================

cp -r 'target_Mar06'/glaceemr_backend/WEB-INF/applicationContext.xml target/glaceemr_backend/WEB-INF/applicationContext.xml

ps -ef |grep -i java


Console:
========
[root@demosprings tmp]# ps -ef | grep -i java
tomcat     1224      1 50 05:21 ?        09:18:29 /usr/java/jdk-10.0.2/bin/java -Djava.util.logging.config.file=/usr/share/tomcat/apache-tomcat-9.0.19/conf/logging.properties -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -Djdk.tls.ephemeralDHKeySize=2048 -Djava.protocol.handler.pkgs=org.apache.catalina.webresources -Dorg.apache.catalina.security.SecurityListener.UMASK=0027 -Djava.library.path=/usr/local/apr/lib -verbose:gc -Djava.awt.headless=true -Djavax.xml.parsers.SAXParserFactory=org.apache.xerces.jaxp.SAXParserFactoryImpl -Xlog:gc*:file=/usr/share/tomcat/apache-tomcat-9.0.19/logs/gc.log -Dignore.endorsed.dirs= -classpath /usr/share/tomcat/apache-tomcat-9.0.19/bin/bootstrap.jar:/usr/share/tomcat/apache-tomcat-9.0.19/bin/tomcat-juli.jar -Dcatalina.base=/usr/share/tomcat/apache-tomcat-9.0.19 -Dcatalina.home=/usr/share/tomcat/apache-tomcat-9.0.19 -Djava.io.tmpdir=/usr/share/tomcat/apache-tomcat-9.0.19/temp org.apache.catalina.startup.Bootstrap start
root      25754  25740  0 23:57 pts/1    00:00:00 grep --color=auto -i java

kill -9 1224

service tomcat9 restart
