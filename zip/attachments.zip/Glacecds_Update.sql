ssh 172.16.24.66
ssh 172.16.24.136
ssh 172.16.24.145

Notes:Common For all Clusters.

cd /usr/share/tomcat/apache-tomcat-9.0.19/webapps/

mv glacecds.war /var/backup/glacecds_Mar07.war
==========================================================================================================

ssh root@ci

cd /var/lib/jenkins/jobs/glacecds_job/workspace/target/
ll

rsync -avzhr --progress glacecds.war vignesh@172.16.24.66:/usr/share/tomcat/apache-tomcat-9.0.19/webapps/
rsync -avzhr --progress glacecds.war vignesh@172.16.24.136:/usr/share/tomcat/apache-tomcat-9.0.19/webapps/
rsync -avzhr --progress glacecds.war vignesh@172.16.24.145:/usr/share/tomcat/apache-tomcat-9.0.19/webapps/
==========================================================================================================
ssh 172.16.24.66
ssh 172.16.24.136
ssh 172.16.24.145

Notes:Common For all Clusters.


chmod -Rcf 777 glacecds.war   glacecds
ls -lrth

ps -ef | grep java


service tomcat9 restart

tail -f /usr/share/tomcat/apache-tomcat-9.0.19/logs/glacecds.log
