D2Desktop UI and springs Update == VMPC-Desktop
*******************************************

D2Desktop UI (Desktop_UI) == VMPC-Desktop (172.16.24.149)
******************************************
ssh vignesh@172.16.24.149 ///dev2-vmpcdesktop

cd /var/version/GlaceEMRDesktop_UI/
ls -lrth
mv target target_Nov23
ls -lrth
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Connect to ci server
************************
ssh root@ci
cd /tmp
cd /var/lib/jenkins/jobs/glaceemr_ui_testing_job/workspace
ls -lrth
rsync -avzh --progress target vignesh@172.17.24.149:/var/version/GlaceEMRDesktop_UI/


Again connect ssh 172.16.24.149
*******************************
cd /var/version/GlaceEMRDesktop_UI/
ls -lrth
chmod -Rf 777 target
chown -Rf root:root target
ls -lrth

service httpd status
service httpd reload
service httpd status

--*********************************************************************************

D2Desktop springs == VMPC-Desktop
*****************************
ssh vignesh@172.16.24.149
*************************

cat src/main/webapp/WEB-INF/applicationContext.xml | grep -i version
cat src/main/java/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.java | grep -i backend   // Need to check for every springs update.


cd /usr/share/tomcat/apache-tomcat-9.0.19/conf/Catalina/localhost/
ls -lrth
cat glaceemr_backend_desktop.xml   ########################(check the codebase path)###############################
cd /var/version/NRVBetaSpring_Testing/
ls -lrth
 mv target target_Dec15
 ls -lrth
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
ci
*******
cd /var/lib/jenkins/jobs/glaceemr_testing_job/workspace/
ls -lrth
rsync -azvh --progress target vignesh@172.17.24.149:/var/version/NRVBetaSpring_Testing/

rsync -azvh --progress target vignesh@172.17.24.149:/var/version/DevelopmentSpringR16

In VMPC-Desktop server:(172.16.24.149)
**********************
cd /var/version/NRVBetaSpring_Testing/
chmod -Rf 777 targetPrint_138731000352252.pdf
chown -Rf root:root target
ls -lrth

///COPY the 'DataBaseAccessFilter.class & applicationContext.xml' files from the Todays Backup TARGET.
-----------------------------------------------------------------------------------------------------
cd /var/version/NRVBetaSpring_Testing/
ls -lrth
cp 'target_Dec21_1'/glaceemr_backend/WEB-INF/classes/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.class  target/glaceemr_backend/WEB-INF/classes/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.class

cp 'target_Dec21_1'/glaceemr_backend/WEB-INF/applicationContext.xml  target/glaceemr_backend/WEB-INF/applicationContext.xml
ls -lrth

/// RELOAD both 'Spring & Lagacy' Context
-----------------------------------------
cd /usr/share/tomcat/apache-tomcat-9.0.19/conf/Catalina/localhost/
ls -lrth
vi glaceemr_backend_desktop.xml
vi D2Desktop.xml

=================================================================================================================================================
=================================================================================================================================================

Central PRODUCTION 'D2Desktp UI' update
======================================
ssh vignesh@172.16.31.30

cd /mnt/MainStorage/version/iPadTesting/GlaceiPadNRVBeta/ ------------> NRVBeta ipad path

cd /mnt/MainStorage/version/CentraliPad/NextRelease/ ------------> NextRelase ipad path

cd /mnt/MainStorage/version/Desktop_UI_Testing/
ls -lrth
mv target target_Dec15
ls -lrth

ssh ci::
*******
cd /var/lib/jenkins/jobs/glaceemr_ui_job/workspace
ls -lrth
rsync -arzvh --progress target vignesh@172.16.31.30:/mnt/MainStorage/version/Desktop_UI_Testing/

Again connect ssh vignesh@172.16.31.30
**************************************
cd /mnt/MainStorage/version/Desktop_UI_Testing/
ls -lrth
chmod -Rf 777 target
chown -Rf root:root target
ls -lrth

////reload httpd in www24
-------------------------
cd /tmp/
service httpd status
service httpd reload
service httpd status

http://emrsprings.glaceemr.com/glaceemr_backend_nrvbeta

=================================================================================================================================================
=================================================================================================================================================

Central PRODUCTION 'Desktop Springs' Update: (Both Testing & Master Branch) -- Need to Update glaceemr_backend_master spring first & Update DesktopSpring.
=========================================================================================================================================================
Connect 172.17.24.92 server:
===========================

'glaceemr_backend_master - UPdate'
=================================
cd /var/version/glaceemr_backend_master/
ls -lrth
mv target target_Jan05
ls -lrth

Connect ci server:
*****************
cd /var/lib/jenkins/jobs/glaceemr_job/workspace
ls -lrth
rsync -arzvh --progress target vignesh@172.16.24.92:/var/version/glaceemr_backend_master/

Connect 172.17.24.92 server:
**************************
cd /var/version/glaceemr_backend_master/
ls -lrth
chmod -Rf 777 target
chown -Rf root:root target
ls -lrth

///COPY the 'DataBaseAccessFilter.class & applicationContext.xml' files from the Todays Backup TARGET.

cd /var/version/glaceemr_backend_master/
ls -lrth
cp -r 'target_Jan05'/glaceemr_backend/WEB-INF/classes/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.class target/glaceemr_backend/WEB-INF/classes/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.class

cp -r 'target_Jan05'/glaceemr_backend/WEB-INF/applicationContext.xml target/glaceemr_backend/WEB-INF/applicationContext.xml
ls -lrth

/// RELOAD 'Spring' Context
---------------------------
cd /usr/share/tomcat/apache-tomcat-9.0.12/conf/Catalina/localhost/
ls -lrth
vi glaceemr_backend_desktop.xml  ////(Reload it)

---------------------------------------------------------------------------------------------------------------
'DesktopSpring - Update'
=======================

cd /var/version/DesktopSpring/
ls -lrth
mv target target_Jan05
ls -lrth

Connect ci server:
*****************
cd /var/lib/jenkins/jobs/glaceemr_testing_job/workspace/
ls -lrth
rsync -arzvh --progress target vignesh@172.16.24.92:/var/version/DesktopSpring/

Connect 172.17.24.92 server:
***************************
cd /var/version/DesktopSpring/
ls -lrth
chmod -Rf 777 target
chown -Rf root:root target
ls -lrth

///COPY the 'DataBaseAccessFilter.class & applicationContext.xml' files from the Todays Backup TARGET.
-----------------------------------------------------------------------------------------------------
cd /var/version/DesktopSpring/
ls -lrth
cp -r target_Jan21/glaceemr_backend/WEB-INF/classes/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.class target/glaceemr_backend/WEB-INF/classes/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.class

cp -r target_Jan21/glaceemr_backend/WEB-INF/applicationContext.xml target/glaceemr_backend/WEB-INF/applicationContext.xml

ls -lrth

/// RELOAD 'Spring' Context
---------------------------
cd /usr/share/tomcat/apache-tomcat-9.0.12/conf/Catalina/localhost/
ls -lrth
vi glaceemr_backend_testing.xml    ////(Reload it)


/// Check if the 172.17.24.92 Spring Server is working fine.
-----------------------------------------------------------
/// TAKE the 'BACKUP' of target files in 172.17.24.98 & 172.17.24.99 servers.
-----------------------------------------------------------------------------
Connect 172.17.24.98 & 172.17.24.99  servers:
============================================

cd /var/version/glaceemr_backend_master/
ls -lrth
mv target target_Jan05
ls -lrth

cd /var/version/DesktopSpring/
ls -lrth
mv target target_Jan05
ls -lrth


/// Then rsync the Working TARGET from 172.17.24.92 Spring Server.
-----------------------------------------------------------------
Connect 172.17.24.92 server:
===========================
rsync -arzvh --progress /var/version/glaceemr_backend_master/target vignesh@172.16.24.98:/var/version/glaceemr_backend_master/
rsync -arzvh --progress /var/version/glaceemr_backend_master/target vignesh@172.16.24.99:/var/version/glaceemr_backend_master/

rsync -arzvh --progress /var/version/DesktopSpring/target vignesh@172.16.24.98:/var/version/DesktopSpring/
rsync -arzvh --progress /var/version/DesktopSpring/target vignesh@172.16.24.99:/var/version/DesktopSpring/

================================================================================================================================================

'WaterburyDesktop_UI ==  Waterbury Server'
------------------------------------------
Connect glenwood@waterburysrv.glaceemr.net
------------------------------------------
cd /var/backup/
ls -lrth
rm -rf target

Connect CI Server:-
-------------------
cd /var/lib/jenkins/jobs/glaceemr_ui_testing_job/workspace
ls -lrth
rsync -avzh --progress target glenwood@waterburysrv.glaceemr.net:/var/backup/

Connect root@10.1.10.46
-----------------------
cd /var/version/Desktop_UI_Testing/
mv target target_Dec28
ls -lrth

Connect glenwood@waterburysrv.glaceemr.net
------------------------------------------
cd /var/backup/
ls -lrth
rsync -arzvh --progress target root@10.1.10.46:/var/version/Desktop_UI_Testing/


Connect root@10.1.10.46
-----------------------
cd /var/version/Desktop_UI_Testing/
ls -lrth
chmod -Rf 777 target
chown -Rf root:root target
ls -lrth

////reload httpd
----------------
cd /tmp/                    
service httpd status
service httpd reload
service httpd status

tail -f /usr/share/tomcat/apache-tomcat-9.0.56/logs/catalina.out

====================================================================================================================================
WaterburyDesktopSprings  ==  Waterbury Server
---------------------------------------------
Connect glenwood@waterburysrv.glaceemr.net
------------------------------------------
cd /var/backup/
ls -lrth
rm -f target

Connect CI Server
-----------------
DesktopSprings:-
----------------
cd /var/lib/jenkins/jobs/glaceemr_testing_job/workspace/
ls -lrth
rsync -avzh --progress target glenwood@waterburysrv.glaceemr.net:/var/backup/

Connect root@10.1.10.46
-----------------------
cd /var/version/DesktopSpring/
ls -lrth
mv target target_Dec28
ls -lrth

Connect glenwood@waterburysrv.glaceemr.net
------------------------------------------
cd /var/backup/
ls -lrth
rsync -arzvh --progress target root@10.1.10.46:/var/version/DesktopSpring/


Connect root@10.1.10.46
-----------------------
cd /var/version/Desktop_UI_Testing/
chmod -Rf 777 target
chown -Rf root:root target
ls -lrth

///COPY the 'DataBaseAccessFilter.class & applicationContext.xml' files from the Todays Backup TARGET.
-----------------------------------------------------------------------------------------------------
cd /var/version/Desktop_UI_Testing/
ls -lrth
cp 'target_Dec28'/glaceemr_backend/WEB-INF/classes/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.class target/glaceemr_backend/WEB-INF/classes/com/glenwood/glaceemr/server/filters/DataBaseAccessFilter.class

cp -r applicationContext.xml target/glaceemr_backend/WEB-INF/applicationContext.xml


/// RELOAD both 'Spring' Context.
--------------------------------
cd /usr/share/tomcat/apache-tomcat-9.0.56/conf/Catalina/localhost/
ls -lrth
vi glaceemr_backend_testing.xml  /////save and close (:wq!)

tail -f /usr/share/tomcat/apache-tomcat-9.0.56/logs/catalina.out

===================================================================================================================================================

Checking URL's:
===============

https://glace-gwt.glaceemr.com/glaceemr_backend_testing_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
https://glace-gwt.glaceemr.com/glaceemr_backend_desktop_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
https://glace-gwt.glaceemr.com/glaceemr_backend_desktop/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
https://glace-gwt.glaceemr.com/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg

http://172.16.24.92/glaceemr_backend_testing_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.92/glaceemr_backend_desktop_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.92/glaceemr_backend_desktop/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.92/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg

http://172.16.24.98/glaceemr_backend_testing_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.98/glaceemr_backend_desktop_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.98/glaceemr_backend_desktop/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.98/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg

http://172.16.24.99/glaceemr_backend_testing_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.99/glaceemr_backend_desktop_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.99/glaceemr_backend_desktop/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.99/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg

http://172.16.24.100/glaceemr_backend_testing_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.100/glaceemr_backend_desktop_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.100/glaceemr_backend_desktop/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.100/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg


http://172.16.24.101/glaceemr_backend_testing_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.101/glaceemr_backend_desktop_stable/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.101/glaceemr_backend_desktop/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.101/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg


http://172.16.24.92/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.98/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.99/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.100/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg
http://172.16.24.101/glaceemr_backend_testing/ccg/api/desktop/user/Scheduler/getSSODetails?accountId=ccg


http://emrsprings1.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings2.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings3.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings4.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings5.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings6.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings7.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings8.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings9.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings10.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings11.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings13.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings14.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings15.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings16.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
http://emrsprings17.glaceemr.com/glaceemr_backend_nrvbeta/api/emr/glacemonitor/monitor/GlaceMonitoringAdapter
