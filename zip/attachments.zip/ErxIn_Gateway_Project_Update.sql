################################### ERXIN_Gateway Project Update Steps #############################################

ERXIN Web Cluster Servers:
=========================
ssh vignesh@erxin1.glaceemr.com
ssh vignesh@erxin2.glaceemr.com
ssh vignesh@erxin3.glaceemr.com

KILL the TOMCAT before UPDATE::
*****************************
cd /tmp/
ps -ef | grep java
kill -9 1234

ps -ef | grep java

Check the Project Path::
**********************
cd /usr/share/tomcat/apache-tomcat-8.5.16/conf/Catalina/localhost/
cat erxinGateway.xml

Backup the Working Project::
**************************
cd /var/version/erxinGateway/
ls -lrth
mv target target_Jun16
ls -lrth

Connect to CI Server::
***********************
cd /var/lib/jenkins/jobs/erxInGateway_job/workspace/
ls -lrth



rsync -azvh --progress /var/lib/jenkins/jobs/erxInGateway_job/workspace/target vignesh@erxin1.glaceemr.com:/var/version/erxinGateway/
rsync -azvh --progress /var/lib/jenkins/jobs/erxInGateway_job/workspace/target vignesh@erxin2.glaceemr.com:/var/version/erxinGateway/
rsync -azvh --progress /var/lib/jenkins/jobs/erxInGateway_job/workspace/target vignesh@erxin3.glaceemr.com:/var/version/erxinGateway/

ErxIn web servers::
*******************
cd /var/version/erxinGateway/
ls -lrth
chmod -Rf 777 target
ls -lrth

Restart Tomcat Service::
**********************
ps -ef | grep java

rm -rf /usr/share/tomcat/apache-tomcat-8.5.16/work/Catalina
service tomcat8 restart
ps -ef | grep java

tail -f  /usr/share/tomcat/apache-tomcat-8.5.16/logs/catalina.out


################################### ERXIN_Gateway Project Update Completed #############################################

Check below URL after Updating all cluster servers
**************************************************
https://erxin.glaceemr.com/erxinGateway/GlaceMonitoringAdapter

URL after Updating all cluster servers
**************************************
https://erxin1.glaceemr.com/erxinGateway/GlaceMonitoringAdapter
https://erxin2.glaceemr.com/erxinGateway/GlaceMonitoringAdapter
https://erxin3.glaceemr.com/erxinGateway/GlaceMonitoringAdapter


