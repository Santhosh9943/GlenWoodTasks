################################### ERXIN_Gateway Project Update Steps #############################################

ERXIN Web Cluster Servers:
=========================
ssh vignesh@erxout1.glaceemr.com
ssh vignesh@erxout2.glaceemr.com
ssh vignesh@erxout3.glaceemr.com

KILL the TOMCAT before UPDATE::
*****************************
cd /tmp/
ps -ef | grep java
kill -9 1234

ps -ef | grep java

Check the Project Path::
**********************
cd /usr/share/tomcat/apache-tomcat-9.0.14/conf/Catalina/erxout.glaceemr.com/
cat SureScripts.xml

Backup the Working Project::
**************************
cd /var/version/erxinGateway/
ls -lrth
mv target target_Jun20
ls -lrth

Connect to CI Server::
***********************
cd /var/lib/jenkins/jobs/erxInGateway_job/workspace/
ls -lrth



rsync -azvh --progress /var/lib/jenkins/jobs/erxInGateway_job/workspace/target vignesh@erxout1.glaceemr.com:/var/version/erxinGateway/
rsync -azvh --progress /var/lib/jenkins/jobs/erxInGateway_job/workspace/target vignesh@erxout2.glaceemr.com:/var/version/erxinGateway/
rsync -azvh --progress /var/lib/jenkins/jobs/erxInGateway_job/workspace/target vignesh@erxout3.glaceemr.com:/var/version/erxinGateway/

ErxIn web servers::
*******************
cd /var/version/erxinGateway/
ls -lrth
chmod -Rf 777 target
ls -lrth

Restart Tomcat Service::
**********************

rm -rf /usr/share/tomcat/apache-tomcat-9.0.14/work/Catalina
service tomcat9 restart
ps -ef | grep java

tail -f  /usr/share/tomcat/apache-tomcat-9.0.14/logs/catalina.out


################################### ERXOUT Gateway Project Update Completed #############################################

Check below URL after Updating all cluster servers
**************************************************
https://erxout.glaceemr.com/SureScripts/GlaceMonitoringAdapter

URL after Updating all cluster servers
**************************************
http://erxout1.glaceemr.com/SureScripts/GlaceMonitoringAdapter
http://erxout2.glaceemr.com/SureScripts/GlaceMonitoringAdapter
http://erxout3.glaceemr.com/SureScripts/GlaceMonitoringAdapter


