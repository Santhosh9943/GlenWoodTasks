Connect Portal1:
================
cd /var/version/glaceportal_data_hxxx
Console
========
[root@portal1 version]# cd /var/version/glaceportal_data_hxxx
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# ls -lrth
total 20K
drwxrwxrwx 4 root root  30 Nov 20  2017 src
-rwxrwxrwx 1 root root  18 Jan  8  2020 Target.sh
-rwxr-xr-x 1 root root 15K Nov 10  2020 pom.xml
drwxrwxrwx 8 root root 171 Jul  1  2022 target_July12
drwxrwxrwx 8 root root 171 Jul 12  2022 target_Nov15
drwxrwxrwx 8 root root 171 Nov 16 03:06 target
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# 
[root@portal1 glaceportal_data_hxxx]# svn info

Path: .
Working Copy Root Path: /var/version/glaceportal_data_hxxx
URL: http://svn1.glaceemr.com:18080/svn/glacegwt/glaceportal_data_hxxx
Repository Root: http://svn1.glaceemr.com:18080/svn/glacegwt
Repository UUID: ee589d99-0113-467c-92c2-acc0d97f98a1
Revision: 12661
Node Kind: directory
Schedule: normal
Last Changed Author: bhagyalakshmi
Last Changed Rev: 12661
Last Changed Date: 2022-07-06 00:58:39 -0400 (Wed, 06 Jul 2022)

Hints::Please take the Backup of working target with todays date and please maintence only two backups and one target folder.

mv target target_Mar07

[root@portal1 glaceportal_data_hxxx]# ls -lrth
total 20K
drwxrwxrwx 4 root root  30 Nov 20  2017 src
-rwxrwxrwx 1 root root  18 Jan  8  2020 Target.sh
-rwxr-xr-x 1 root root 15K Nov 10  2020 pom.xml
drwxrwxrwx 8 root root 171 Jul  1  2022 target_July12
drwxrwxrwx 8 root root 171 Jul 12  2022 target_Nov15
drwxrwxrwx 8 root root 171 Nov 16 03:06 target_Mar07

Console
========
[root@portal1 glaceportal_data_hxxx]# cd /usr/share/tomcat/apache-tomcat-9.0.14/webapps/
[root@portal1 webapps]# 
[root@portal1 webapps]# 
[root@portal1 webapps]# 
[root@portal1 webapps]# 
[root@portal1 webapps]# ls -lrth
total 32M
drwxrwxrwx 5 root   root   103 Mar 26  2019 Manager
drwxrwxrwx 3 root   root   283 Nov 22  2019 ROOT
drwxr-x--- 5 tomcat tomcat  97 Jun 10  2022 glaceportal
-rwxrwxrwx 1 root   root   32M Nov 16 03:09 glaceportal_data.war
drwxrwxrwx 5 tomcat tomcat  97 Nov 16 03:09 glaceportal_data

mv glaceportal_data.war /var/version/glaceportal_data_Mar07.war

cp -r /var/version/glaceportal_data_hxxx/target/glaceportal_data.war /usr/share/tomcat/apache-tomcat-9.0.14/webapps/

ps -ef |grep -i java


service tomcat9 restart


=================================================================================================================================================

cd /var/version/glaceportal_ui/

Hints::Please take the Backup of working target with todays date and please maintence only two backups and one target folder.

mv target target_Mar07

[root@portal1 glaceportal_ui]# ls -lrth
total 20K
drwxrwxrwx 4 root root  30 Nov 20  2017 src
-rwxrwxrwx 1 root root  18 Jan  8  2020 Target.sh
-rwxr-xr-x 1 root root 15K Nov 10  2020 pom.xml
drwxrwxrwx 8 root root 171 Jul  1  2022 target_July12
drwxrwxrwx 8 root root 171 Jul 12  2022 target_Nov15
drwxrwxrwx 8 root root 171 Nov 16 03:06 target_Mar07

Connect CI:
===========

cd /var/lib/jenkins/jobs/glaceportal_ui_job/workspace

ls -lrth

Console
========
root@ci:/var/lib/jenkins/jobs/glaceportal_ui_job/workspace# 
root@ci:/var/lib/jenkins/jobs/glaceportal_ui_job/workspace# 
root@ci:/var/lib/jenkins/jobs/glaceportal_ui_job/workspace# ls -lrth
total 24K
-rwxr-xr-x  1 jenkins nogroup  16K Feb 21 18:13 pom.xml
drwxr-xr-x  4 jenkins nogroup 4.0K Feb 21 18:13 src
drwxr-xr-x 13 jenkins nogroup 4.0K Feb 21 18:18 target


rsync -avrzh --progress target vignesh@portal1.glaceemr.com:/var/version/glaceportal_ui/

Connect Portal1:
================

service httpd restart






